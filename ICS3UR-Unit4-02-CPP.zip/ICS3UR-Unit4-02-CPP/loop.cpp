// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This program calculates factorials

#include <iostream>
#include <string>

int main() {
    int im;
    int loop = 1;
    int summ = 1;
    std::string imAsString;

    // input
    std::cout << "We will be calculating factorials." << std::endl;
    std::cout << "Enter an integer: ";
    std::cin >> imAsString;
    std::cout << "" << std::endl;

    try {
        im = std::stoi(imAsString);

        if (im >= 0) {
            if (im != 0) {
                while (loop <= im) {
                    summ = summ * loop;
                    loop = loop + 1;
                } std::cout << im << "! is " << summ << std::endl;
            } else {
                std::cout << "0! is 1" << std::endl;
            }
        } else {
            std::cout << "That is a negative integer."
            << std::endl;
        }
    } catch (std::invalid_argument) {
        std::cout << "That is not an integer" << std::endl;
    }
}
